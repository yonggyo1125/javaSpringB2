package org.koreait;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam01Application {

	public static void main(String[] args) {
		SpringApplication.run(Exam01Application.class, args);
	}

}
